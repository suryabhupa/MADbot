
== Example with the MNIST dataset ==

1.Change the *pdnndir* and *device* variables in run.sh  

2.Run run.sh in the terminal. You will see the following log  

Preparing datasets ...   
Training the DNN model ...   
Classifying with the DNN model ...   
Error rate is 1.92 (%)   
Training the CNN model ...   
Classifying with the CNN model ...   
Error rate is 0.94 (%)   




#!/bin/sh
export DYLD_LIBRARY_PATH=/Users/surya/IAP_2016_Pokerbots/MADbot/pbots_calc/export/darwin/lib:$LD_LIBRARY_PATH
/Users/surya/IAP_2016_Pokerbots/MADbot/pbots_calc/example/calculator $@

#!/bin/sh
export DYLD_LIBRARY_PATH=/Users/surya/IAP_2016_Pokerbots/MADbot/pbots_calc/export/darwin/lib:$LD_LIBRARY_PATH
java -cp /Users/surya/IAP_2016_Pokerbots/MADbot/pbots_calc/java/jnaerator-0.11-SNAPSHOT-20121008.jar:/Users/surya/IAP_2016_Pokerbots/MADbot/pbots_calc/java/bin pbots_calc.Calculator $@